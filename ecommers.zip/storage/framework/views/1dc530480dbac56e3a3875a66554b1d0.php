<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    Login
</body>
</html><?php /**PATH E:\laragon\www\rest-api_sakubudget\resources\views/login.blade.php ENDPATH**/ ?>